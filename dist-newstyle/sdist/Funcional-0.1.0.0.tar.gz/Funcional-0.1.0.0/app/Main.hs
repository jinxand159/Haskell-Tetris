{-# LANGUAGE OverloadedStrings #-}

module Main where
import Graphics.Blank

-- 3000 es el puerto
-- fillStyle "blue" es cambiando el color
-- fillRect (50, 50, 100, 100), dibuja un rectángulo relleno, como los bollycaos
main :: IO   ()
main = blankCanvas 3000 $ \ context -> do
    send context $ do
        fillStyle "blue"
        fillRect (50, 50, 100, 100)

send context $ do
    beginPath()
    moveTo(75, 50)
    lineTo(100, 75)
    lineTo(100, 25)
    stroke()